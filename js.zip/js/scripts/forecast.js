const key = 'j9rfbR7gk7KBebw8uR99jMEdWST3V3r5';

// Get weather info
const getWeather = async (id) => {
    const base = 'http://dataservice.accuweather.com/currentconditions/v1/';
    const query = `${id}?apikey=${key}`;

    const response = await fetch(base + query);
    const data = await response.json();

    return data[0];
};

// Get city info
const getCity = async (city) => {
    const base = 'http://dataservice.accuweather.com/locations/v1/cities/search';
    const query = `?apikey=${key}&q=${city}`;

    const response = await fetch(base + query);
    const data = await response.json();

    return data[0];
};

// Get city image from Unsplash API
const getCityImage = async (city) => {
    const accessKey = 'Q78gUqMQpxzva_H2Bhwu1Nl7jB3LAlUNG-3cRn__STM'; 
    const base = `https://api.unsplash.com/search/photos`;
    const query = `?query=${city}&client_id=${accessKey}&orientation=landscape`;

    const response = await fetch(base + query);
    const data = await response.json();

    return data.results[0].urls.regular; 
};
